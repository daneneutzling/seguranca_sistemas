#!/usr/bin/env python
# coding: utf8

import random

for i in range(10):
	x = random.random()
	print (x)
	
for i in range(10):
	x = random.random()
	print (int(x * 80))
