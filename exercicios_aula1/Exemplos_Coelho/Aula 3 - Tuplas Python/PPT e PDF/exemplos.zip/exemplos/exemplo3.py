def main():
	tupla = (1, 2)
	dicionario = {"um": 1, "dois": 2}
	f(tupla, dicionario)

def f(tupla, dicionario):
	print ("Tupla:", tupla)
	print ("Dicionário:", dicionario)
    
main()
