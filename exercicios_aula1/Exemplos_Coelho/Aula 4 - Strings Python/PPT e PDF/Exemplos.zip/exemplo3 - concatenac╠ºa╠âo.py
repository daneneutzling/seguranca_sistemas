#!/usr/bin/env python
# coding: utf8

__AUTHOR__ = "Rafael Vieira Coelho"
__DATE__ = "31/03/2019"

first_name = "ada" 
last_name = "lovelace"
full_name = first_name + " " + last_name 
print(full_name)
