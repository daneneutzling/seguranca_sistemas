#!/usr/bin/env python
# coding: utf8


__AUTHOR__ = "Rafael Vieira Coelho"
__DATE__ = "31/03/2019"

import string

print (string.ascii_letters)
print (string.ascii_lowercase)
print (string.ascii_uppercase)
print (string.digits)
