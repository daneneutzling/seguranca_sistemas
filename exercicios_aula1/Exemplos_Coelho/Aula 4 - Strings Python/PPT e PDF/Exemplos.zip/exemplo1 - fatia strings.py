#!/usr/bin/env python
# coding: utf8


__AUTHOR__ = "Rafael Vieira Coelho"
__DATE__ = "31/03/2019"

fruta = "banana"
print("fruta = " + fruta)
print("fruta[:3] = " + fruta[:3])
print("fruta[3:] = " + fruta[3:])
print("fruta[:]  = " + fruta[:])
