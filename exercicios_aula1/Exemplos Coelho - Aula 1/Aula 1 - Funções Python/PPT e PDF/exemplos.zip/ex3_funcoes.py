#!/usr/bin/env python
# coding: utf8

def novaLinha() :
	print('')

def tresLinhas() :
	novaLinha()
	novaLinha()
	novaLinha()

print ('Primeira Linha.')
tresLinhas()
print ('Segunda Linha.')
