def soma(a, b):
	return a + b

def subtrai(a, b):
	return a - b

def multiplica(a, b):
	return a * b

def divide(a, b):
	if b == 0:
		return 0
	return a / b
