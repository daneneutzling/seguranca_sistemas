from matematica import soma

def main():
	v1 = int(input('Qual o primeiro valor?'))
	v2 = int(input('Qual o segundo valor?'))
	res = soma(v1, v2) 
	print('Resultado = ', res)

main()
