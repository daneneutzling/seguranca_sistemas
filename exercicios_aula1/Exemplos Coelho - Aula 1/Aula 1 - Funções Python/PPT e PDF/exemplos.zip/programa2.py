import matematica as mat

def main():
	v1 = int(input('Qual o primeiro valor?'))
	v2 = int(input('Qual o segundo valor?'))
	res = mat.multiplica(v1, v2) 
	print('Resultado = ', res)

main()
