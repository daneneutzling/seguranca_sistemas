#!/usr/bin/env python
# coding: utf8

def main():
	n1 = int(input("Qual é o primeiro número?"))
	n2 = int(input("Qual é o segundo número?"))
	n3 = int(input("Qual é o terceiro número?"))
	n4 = int(input("Qual é o quarto número?"))
	somatorio = n1 + n2 + n3 + n4
	print("Somatório: ", somatorio)
	resultado = n1 * n2 * n3 * n4
	print("Resultado da multiplicação: ", resultado)

main()
